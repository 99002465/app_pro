package com.ltts.shadowproject.model;

public class datamodel {
    String category;
    String task;


    public datamodel(String category, String task)//, String task ) {
    {
        this.task = task;
        this.category = category;
    }

    public String gettask() {
        return task;
    }

    public String getCategory() {
        return category;
    }

    public void settask(String task) {
        this.task = task;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
