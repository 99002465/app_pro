package com.ltts.shadowproject;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.sax.TextElementListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.ltts.shadowproject.adpaters.Adap;
import com.ltts.shadowproject.fragments.Dialogue_Fragment;
import com.ltts.shadowproject.fragments.ThirdScreen;

import java.util.ArrayList;


public class RecyclerFragment extends Fragment {
    private RecyclerView mRecyclerview;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
ArrayList<Listfragment>exlist;
FloatingActionButton add_note;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        ArrayList<Listfragment> exlist = new ArrayList<>();
        exlist.add(new Listfragment(R.drawable.s, "Blood Test", "Thrusday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Temprature Check", "Friday @10PM"));
        exlist.add(new Listfragment(R.drawable.s, "Doc appointment", "Monday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Medicine Purchase", "Thrusday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Get prescription", "Thrusday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Books", "Monday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Sleep", "Friday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Health", "Thrusday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Books", "Thrusday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Sleep", "Friday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Health", "Thrusday @9PM"));
        exlist.add(new Listfragment(R.drawable.s, "Books", "Monday @9PM"));



        View rootView = inflater.inflate(R.layout.fragment_recycler, container, false);
        rootView.findViewById(R.id.recyclerview);
        mRecyclerview = rootView.findViewById(R.id.recyclerview);
        mLayoutManager = new LinearLayoutManager(this.getContext());
        mAdapter = new Adap(exlist);
        mRecyclerview.setLayoutManager(mLayoutManager);
        mRecyclerview.setAdapter(mAdapter);

        add_note = rootView.findViewById(R.id.add_note);
        add_note.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppCompatActivity appCompatActivity = (AppCompatActivity) v.getContext();
               ThirdScreen thirdScreen = new ThirdScreen();
                appCompatActivity.getSupportFragmentManager().beginTransaction().replace(R.id.maincontainer, thirdScreen).addToBackStack(null).commit();

            }
        });



        //swipe delete
       Listfragment deletelist=null;
       new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(1, ItemTouchHelper.LEFT
               |ItemTouchHelper.RIGHT ) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                switch (direction) {
                    case ItemTouchHelper.LEFT:
                        exlist.remove(position);
                        mAdapter.notifyItemRemoved(position);
                        Snackbar.make(mRecyclerview, (CharSequence) deletelist,Snackbar.LENGTH_LONG)
                                .setAction("Undo", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        exlist.add(position,deletelist);
                                        mAdapter.notifyItemInserted(position);
                                    }
                                });
                        break;

                }
            }
        }).attachToRecyclerView(mRecyclerview);


        return rootView;
        //return inflater.inflate(R.layout.fragment_recycler, container, false);
    }


    }
    

