package com.ltts.shadowproject.fragments;

import android.app.AlertDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.ltts.shadowproject.R;
import com.ltts.shadowproject.model.datamodel;
import com.ltts.shadowproject.adpaters.myadapter;

import java.util.ArrayList;

import static android.view.View.*;


public class datafragment extends Fragment {

    RecyclerView recyclerView;
    ArrayList<datamodel> dataholder;
    FloatingActionButton add;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_datafragment, container, false);
        setHasOptionsMenu(true);

        add = view.findViewById(R.id.add);
        add.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialogue_Fragment mydialog = new Dialogue_Fragment();
                mydialog.show(getFragmentManager(), "Dialogue_Fragment");
            }
        });

        recyclerView = view.findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        dataholder = new ArrayList<>();
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));
        dataholder.add ( new datamodel("Health","2 tasks"));


        recyclerView.setAdapter(new myadapter(dataholder));


        return view;
    }

   /* @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu, menu);
        MenuItem item = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                return false;
            }
        });

        super.onCreateOptionsMenu(menu, inflater);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        boolean showMessage = false;

        String message = "You click ";


        if (itemId == R.id.share) {
            showMessage = true;
            message += "share";
        } else if (itemId == R.id.delete) {
            showMessage = true;
            message += "delete";
        }

        if (showMessage) {
            AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
            alertDialog.setMessage(message);
            alertDialog.show();
        }

        return super.onOptionsItemSelected(item);
    }*/
    ItemTouchHelper.SimpleCallback itemTouchHelperCallback=new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

        }
    };
}
